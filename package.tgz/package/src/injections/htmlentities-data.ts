export const htmlentitiesData: string[] = [
    '\' - &apos;',
    '< - &lt;',
    '> - &gt;',
    '® - &reg;',
    '& - &amp;',
    '$ - &dollar;',
    '´ - &acute;',
    '© - &copy;',
    'À - &Agrave;',
    'Á - &Aacute;',
    '- &Acirc;',
    'Ã - &Atilde;',
    'Ä - &Auml;',
    'Å - &Aring',
    'Æ - &AElig;',
    'à - a&#768;',
    'á - a&#769;'
];
