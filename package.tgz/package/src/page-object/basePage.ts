export class BasePage {
}
